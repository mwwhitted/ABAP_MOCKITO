# BSP name in GM6/001
zservicepoc1

# frontend application
https://github.wdf.sap.corp/i042416/service_poc
