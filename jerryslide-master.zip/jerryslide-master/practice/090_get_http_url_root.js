var a = "http://ss.bdimg.com/static/superman/img/logo/logo_white_fe6da1ec.png";
//var root = (new RegExp(/^.*\//)).exec(window.location.href)[0]
var root = (new RegExp(/^.*\//)).exec(a)[0];
console.log(root); // http://ss.bdimg.com/static/superman/img/logo/
