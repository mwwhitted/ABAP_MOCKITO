# 2016-12-4
14:05 - Aircraft takes off 
14:53 - 97%
15:15 - 93% water serving is on
16:07 - 90% - had lunch and have a sleep for a while
16:15 - left hour: 07:19
16:25 - 87%
17:02 - 81% 
17:55 - 79%
18:18 - 75%
18:37 - 72% 
18:50 - 69%
19:23 - 67%
19:43 - 63%
20:00 - 60%
20:14 - 59%, left hour: 3:22
20:25 - 57%
20:59 - 50%
21:08 - 49%
21:18 - 46%, super is coming
22:28 - 45% 
23:42 - 43%

# in Beijing to Chengdu
 9:27 93% 
10:36 89% - delayed again!!!!
